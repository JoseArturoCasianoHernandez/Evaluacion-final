package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class QuintoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quinto)

        val button14 =findViewById<Button>(R.id.button14)
        button14.setOnClickListener {
            val lanzar = Intent (this, CuartoActivity::class.java)
            startActivity(lanzar)
        }
    }
}