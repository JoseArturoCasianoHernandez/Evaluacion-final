package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class NovenoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_noveno)

        val button20 =findViewById<Button>(R.id.button20)
        button20.setOnClickListener {
            val lanzar = Intent (this, DecimoActivity::class.java)
            startActivity(lanzar)
        }
    }
}