package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class CuartoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuarto)

        val button13 =findViewById<Button>(R.id.button13)
        button13.setOnClickListener {
            val lanzar = Intent (this, MainActivity::class.java)
            startActivity(lanzar)
        }
        val button8 =findViewById<Button>(R.id.button8)
        button8.setOnClickListener {
            val lanzar = Intent (this, QuintoActivity::class.java)
            startActivity(lanzar)
        }
        val button9 =findViewById<Button>(R.id.button9)
        button9.setOnClickListener {
            val lanzar = Intent (this, SextoActivity::class.java)
            startActivity(lanzar)
        }
        val button10 =findViewById<Button>(R.id.button10)
        button10.setOnClickListener {
            val lanzar = Intent (this, OctavoActivity::class.java)
            startActivity(lanzar)
        }
        val button11 =findViewById<Button>(R.id.button11)
        button11.setOnClickListener {
            val lanzar = Intent (this, DecimoPrimeroActivity::class.java)
            startActivity(lanzar)
        }
        val button12 =findViewById<Button>(R.id.button12)
        button12.setOnClickListener {
            val lanzar = Intent (this, DecimoQuintoActivity::class.java)
            startActivity(lanzar)
        }
    }
}