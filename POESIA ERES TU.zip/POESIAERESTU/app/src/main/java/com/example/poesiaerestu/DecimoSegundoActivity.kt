package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DecimoSegundoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_segundo)

        val button24 =findViewById<Button>(R.id.button24)
        button24.setOnClickListener {
            val lanzar = Intent (this, DecimoTerceraActivity::class.java)
            startActivity(lanzar)
        }
    }
}