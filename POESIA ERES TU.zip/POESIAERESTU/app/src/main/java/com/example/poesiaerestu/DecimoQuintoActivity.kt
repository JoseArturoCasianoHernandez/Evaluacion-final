package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DecimoQuintoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_quinto)

        val button34 =findViewById<Button>(R.id.button34)
        button34.setOnClickListener {
            val lanzar = Intent (this, DecimoSextoActivity::class.java)
            startActivity(lanzar)
        }
        val button36 =findViewById<Button>(R.id.button36)
        button36.setOnClickListener {
            val lanzar = Intent (this, DecimoSeptimoActivity::class.java)
            startActivity(lanzar)
        }
        val button38 =findViewById<Button>(R.id.button38)
        button38.setOnClickListener {
            val lanzar = Intent (this, CuartoActivity::class.java)
            startActivity(lanzar)
        }
    }
}