package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DecimoCuartoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_cuarto)

        val button28 =findViewById<Button>(R.id.button28)
        button28.setOnClickListener {
            val lanzar = Intent (this, DecimoPrimeroActivity::class.java)
            startActivity(lanzar)
        }
    }
}