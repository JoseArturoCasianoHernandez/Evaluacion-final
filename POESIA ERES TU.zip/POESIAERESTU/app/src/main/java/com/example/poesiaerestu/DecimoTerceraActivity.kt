package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DecimoTerceraActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_tercera)

        val button25 =findViewById<Button>(R.id.button25)
        button25.setOnClickListener {
            val lanzar = Intent (this, DecimoCuartoActivity::class.java)
            startActivity(lanzar)
        }
    }
}