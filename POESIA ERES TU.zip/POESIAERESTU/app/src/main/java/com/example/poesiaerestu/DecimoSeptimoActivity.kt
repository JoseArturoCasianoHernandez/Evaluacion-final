package com.example.poesiaerestu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DecimoSeptimoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_septimo)
    }
}