package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SextoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sexto)

        val button15 =findViewById<Button>(R.id.button15)
        button15.setOnClickListener {
            val lanzar = Intent (this, SeptimoActivity::class.java)
            startActivity(lanzar)
        }
        val button43 =findViewById<Button>(R.id.button43)
        button43.setOnClickListener {
            val lanzar = Intent (this, CuartoActivity::class.java)
            startActivity(lanzar)
        }
    }
}