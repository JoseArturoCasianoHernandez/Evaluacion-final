package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class OctavoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_octavo)

        val button19 =findViewById<Button>(R.id.button19)
        button19.setOnClickListener {
            val lanzar = Intent (this, NovenoActivity::class.java)
            startActivity(lanzar)
        }
    }
}