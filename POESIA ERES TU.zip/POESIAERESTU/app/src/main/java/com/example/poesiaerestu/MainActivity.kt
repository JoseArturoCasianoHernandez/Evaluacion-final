package com.example.poesiaerestu

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button3 =findViewById<Button>(R.id.button3)
        button3.setOnClickListener {
            val lanzar = Intent (this, SegundoActivity::class.java)
            startActivity(lanzar)
        }
        val button1 =findViewById<Button>(R.id.button1)
        button1.setOnClickListener {
            val lanzar = Intent (this, TerceroActivity::class.java)
            startActivity(lanzar)
        }
    }
}