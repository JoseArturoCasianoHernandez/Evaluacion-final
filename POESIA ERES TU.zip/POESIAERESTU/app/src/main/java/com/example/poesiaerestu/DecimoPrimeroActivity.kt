package com.example.poesiaerestu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DecimoPrimeroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_decimo_primero)

        val button23 =findViewById<Button>(R.id.button23)
        button23.setOnClickListener {
            val lanzar = Intent (this, DecimoSegundoActivity::class.java)
            startActivity(lanzar)
        }
        val button29 =findViewById<Button>(R.id.button29)
        button29.setOnClickListener {
            val lanzar = Intent (this, CuartoActivity::class.java)
            startActivity(lanzar)
        }
        val button42 =findViewById<Button>(R.id.button42)
        button42.setOnClickListener {
            val lanzar = Intent (this, SextoActivity::class.java)
            startActivity(lanzar)
        }
    }
}